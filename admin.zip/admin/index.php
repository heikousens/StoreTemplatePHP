<?php include "includes/header.php" ?>

<div class="container">
<div class="row">
<div class="col-xs-12">
<?php include "includes/sidebar.php" ?>
		  <div class="col-xs-12 col-sm-12 col-md-9 col-lg-9">
		  	<div class="row">
		  		<div class="col-md-12">
		  			<div class="content-box-large">
					<div class="thumbnail">
							<div class="welcome-title">Bem Vindo Ao Painel de Controle, <?php echo $_SESSION['login']; ?>!</div>
							<br/>
							<br/>
						<p class="body-text">A área permite controlar todas as informações que são armazenadas no banco de dados</p>
						<p class="body-text">O Administrador poderá alterar e fazer modificações em seu dados e verificar o que foi repassado pelos seus clientes.</p>
		  				</div>
		  			</div>
		  		</div>		  		
		  	</div> 	
		  </div>
		 
</div>
</div>
</div>

<?php include "includes/footer.php" ?>