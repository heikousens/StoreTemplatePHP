<?php

	error_reporting( ~E_NOTICE );
	
	require_once 'conexao.php';
	
	if(isset($_GET['codproduto']) && !empty($_GET['codproduto']))
	{
	$codproduto = $_GET["codproduto"];
	$sql = "SELECT * FROM produto WHERE codproduto = $codproduto";
    $consulta = mysqli_query($conexao, $sql);
	if(mysqli_num_rows ($consulta) == ' '){
	echo "Produto não cadastrado";
	}else{
   $row = mysqli_fetch_array($consulta);
   $codproduto = $row["codproduto"];
   $descricao= $row["descricao"];   
   $categoria = $row["categoria"];
   $preco = $row["preco"];
   $imagem = $row["imagem"];
	}
	
	if (isset($_POST['alterar'])) {
		// Recupera os dados dos campos
		$nomeproduto = $_POST["nomeproduto"];
		$descricao = $_POST["descricao"];
		$categoria = $_POST["categoria"];
		$preco = $_POST["preco"];
	
		$imagem = $_FILES["imagem"];
		// Se a foto estiver sido selecionada
	if (!empty($imagem["name"])) {
		// Largura máxima em pixels
		$largura = 95000;
		// Altura máxima em pixels
		$altura = 980000;
		// Tamanho máximo do arquivo em bytes
		$tamanho = 1000000000;
		$error = array();
    	// Verifica se o arquivo é uma imagem
    	if(!preg_match("/^image\/(pjpeg|jpeg|png|gif|bmp)$/", $imagem["type"])){
     	   $error[1] = "Isso não é uma imagem.";
   	 	} 
		// Pega as dimensões da imagem
		$dimensoes = getimagesize($imagem["tmp_name"]);
		// Verifica se a largura da imagem é maior que a largura permitida
		if($dimensoes[0] > $largura) {
			$error[2] = "A largura da imagem não deve ultrapassar ".$largura." pixels";
		}
		// Verifica se a altura da imagem é maior que a altura permitida
		if($dimensoes[1] > $altura) {
			$error[3] = "Altura da imagem não deve ultrapassar ".$altura." pixels";
		}	
		// Verifica se o tamanho da imagem é maior que o tamanho permitido
		if($imagem["size"] > $tamanho) {
   		 	$error[4] = "A imagem deve ter no máximo ".$tamanho." bytes";
		}
		// Se não houver nenhum erro
		if (count($error) == 0) {
			// Pega extensão da imagem
			preg_match("/\.(gif|bmp|png|jpg|jpeg){1}$/i", $imagem["name"], $ext);
        	// Gera um nome único para a imagem
        	$nome_imagem = md5(uniqid(time())) . "." . $ext[1];
        	// Caminho de onde ficará a imagem
        	$caminho_imagem = "../Imagens/" . $nome_imagem;
			// Faz o upload da imagem para seu respectivo caminho
			move_uploaded_file($imagem["tmp_name"], $caminho_imagem);
			// Insere os dados no banco
			
			
			$sql = "UPDATE produto SET nomeproduto = '$nomeproduto', descricao = '$descricao', categoria = '$categoria', preco = '$preco', imagem = '$nome_imagem'  
WHERE codproduto = '$codproduto";
			mysqli_query($conexao,$sql);
			
			// Se os dados forem inseridos com sucesso
			if ($sql){
				echo "Produto cadastrado com sucesso.";
			}
		}
		// Se houver mensagens de erro, exibe-as
		if (count($error) != 0) {
			foreach ($error as $erro) {
				echo $erro . "<br />";
			}
		}
		}
	}
	}
?>
	
	
	

<?php include "includes/header.php" ?>
<section class="container">
	<?php require "includes/sidebar.php" ?> 
	<div class="col-md-9">
		  	<div class="row">
		<div class="col-md-12">
		<div class="thumbnail">
		  			<div class="content-box-large">
		  				<div class="panel-heading">
							<div class="panel-title">
				  <h1 align="center">Editar Produto</h1>
			</div>
						</div>
		  	<div class="panel-body">
			
			
   

<form action="<?php echo $_SERVER['PHP_SELF'] ?>?codproduto" method="POST" name="alterar"  enctype="multipart/form-data" class="form-horizontal">
	
    
    <?php
	if(isset($errMSG)){
		?>
        <div class="alert alert-danger">
          <span class="glyphicon glyphicon-info-sign"></span> &nbsp; <?php echo $errMSG; ?>
        </div>
        <?php
	}
	?>
   
   
				<div class="form-group">
					<label class="col-sm-2 control-label">Nome do Produto</label>
					<div class="col-sm-10">
						<input type="text" name="descricao" class="form-control" id="inputEmail3" placeholder="Nome do produto" value="<?php echo $row['nomeproduto']; ?>">
					</div>
				</div>
				
				<div class="form-group">
					<label class="col-sm-2 control-label">Descrição</label>
					<div class="col-sm-10">
						<textarea type="text" name="descricao" rows="8" style="resize:none;" class="form-control" id="inputEmail3" placeholder="Descrição do produto" value="<?php echo $row['descricao']; ?>"></textarea>
					</div>
				</div>
				
				<div class="form-group">
					<label class="col-sm-2 control-label">Categoria</label>
					<div class="col-sm-10">
						<input type="text" name="categoria" class="form-control" id="inputEmail3" placeholder="Categoria" value="<?php echo $row['categoria']; ?>">
					</div>
				</div>
				
				<div class="form-group">
					<label class="col-sm-2 control-label">Preço</label>
					<div class="col-sm-10">
						<input type="text" name="preco" class="form-control" id="inputEmail3" placeholder="Preço" value="<?php echo $row['preco']; ?>">
					</div>
				</div>
			
				
				<div class="form-group">
					<label class="col-sm-2 control-label">Imagem</label>
					<div class="col-sm-10">
						<a href="#" class="thumbnail">
						 <img src="../Imagens/<?=$row['imagem']?>" height="190" width="150">
						     
						</a>
					
					<input  class="input-group" type="file" name="imagem"  accept="image/*"  >
				</div>
				</div>
						
				<button type="submit" name="alterar" class="btn btn-carrinho">
        <span class="glyphicon glyphicon-save"></span> Alterar
        </button>	
				
					</div>
					
				</div>
			</form>
		  
    
	
</form>
</div>
		  		</div>		  		
		  	</div> 	
		  </div>
		</div>
    </div>
	</section>



<?php include "includes/footer.php" ?>



