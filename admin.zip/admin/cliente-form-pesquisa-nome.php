<?php $title ="Pesquisa de Cliente"; ?>
<?php require "includes/header.php" ?>
  
<div class="container">
  <?php require "includes/sidebar.php" ?>     
	 <div class="col-md-9">
		  	<div class="row">
		<div class="col-md-12">
		<div class="thumbnail">
		  			<div class="content-box-large">
		  				<div class="panel-heading">
							<div class="panel-title" align="center">
				  <h1>Pesquisar Cliente</h1>
			</div>
						</div>
		  	<div class="panel-body">
				<form class="form-system" method="post" 
					  action="cliente-pesquisa-nome.php">

					<div class="form-group">
							<label class="col-sm-1 control-label">Nome</label>
							<div class="col-sm-5">
								<input type="text"  name="nome" class="form-control"/>
							</div>
							
							
					</div>		
					
					
			<label></label>
			<input type="submit"  class="btn btn-carrinho" name="botao" value="Pesquisar" /> 
		</form>
        	</div>
		  		</div>		  		
		  	</div> 	
		  </div>
		</div>
    </div>
	</div>
</section>
    
    <?php require "includes/footer.php"; ?>
    
