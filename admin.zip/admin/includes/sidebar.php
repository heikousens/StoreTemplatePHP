<div class="col-xs-12 col-sm-12 col-md-3 col-lg-3">
	<div class="panel-group">
		<div class="panel panel-default">
			<div class="panel-heading" style="font: 19px Garamond; background-color: #EEB4B4;"><a href="index.php" style="color: #FFFFFF;"><i class="glyphicon glyphicon-home"></i> Início</a></div>
		</div>
		<br/>
		<div class="panel panel-default">
			<a data-toggle="collapse" href="#collapse1"><div class="panel-heading" style="font: 19px Garamond; background-color: #EEB4B4; color: #FFFFFF;"><i class="glyphicon glyphicon-lock"></i> Acesso Restrito</div></a>
			<div id="collapse1" class="panel-collapse collapse">
					  <div class="panel-body" style="font: 19px Garamond;"><a href="restrito-cadastrar.php"><i class="icon-inbox"></i>Cadastrar Usuários Administrativos</a></div>
					  <div class="panel-body" style="font: 19px Garamond;"><a href="restrito-lista.php"><i class="icon-inbox"></i>Lista de Usuários </a></div>
					  <div class="panel-body" style="font: 19px Garamond;"><a href="restrito-form-pesquisa-nome.php"><i class="icon-inbox"></i>Pesquisar Usuários </a></div>
					  </div>
					</div>
					<br/>
					<div class="panel panel-default">
					  <a data-toggle="collapse" href="#collapse2"><div class="panel-heading" style="font: 19px Garamond; background-color: #EEB4B4; color: #FFFFFF;"><i class="glyphicon glyphicon-user"></i> Cliente</div></a>
					  <div id="collapse2" class="panel-collapse collapse">
					  <div class="panel-body" style="font: 19px Garamond;"><a href="cliente-lista.php">Clientes Cadastrados</a></div>
					  <div class="panel-body" style="font: 19px Garamond;"><a href="cliente-form-pesquisa-nome.php">Pesquisar Cliente</a></div>
					  </div>
					</div>
					<br/>
					<div class="panel panel-default">
					  <a data-toggle="collapse" href="#collapse3"><div class="panel-heading" style="font: 19px Garamond; background-color: #EEB4B4; color: #FFFFFF;"><i class="glyphicon glyphicon-shopping-cart"></i> Produtos</div></a>
					  <div id="collapse3" class="panel-collapse collapse">
					  <div class="panel-body" style="font: 19px Garamond;"><a href="form-produto.php"><i class="icon-inbox"></i>Cadastrar Produto </a></div>
					  <div class="panel-body" style="font: 19px Garamond;"><a href="produto-lista.php">Produtos Cadastrados</a></div>
					  <div class="panel-body" style="font: 19px Garamond;"><a href="produto-form-pesquisa-nome.php">Pesquisar Produto</a></div>
					  </div>
					</div>
					<br/>
					<div class="panel panel-default">
					<div class="panel-heading" style="font: 19px Garamond; background-color: #EEB4B4;"><a href="cliente-sair.php" style="color: #FFFFFF;"><i class="glyphicon glyphicon-log-out"></i> Sair</a></div>
					</div>
	</div>
</div>