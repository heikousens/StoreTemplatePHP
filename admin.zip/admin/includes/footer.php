<footer>
	<div class="col-xs-4">
	<br/>
	<br/>
	<br/>
	<br/>
	<p style="font-family: Pristina, sans-serif; font-size: 100px; text-align: center;">tarsila.</p>
	<br/>
	</div>
	<div class="col-xs-4">
	<br/>
	<br/>
	<br/>
	<h2 style="font-family: Garamond; color: #e79797; text-align: center;">Encontre-nos nas redes sociais!</h2>
	<div class="caption" align="center">
	<br/>
		<a href="#" title="twitter"><i class="fa fa-twitter" style="font-size:30px; color: #e79797;" aria-hidden="true"></i></a>
		<a href="#" title="instagram"><i class="fa fa-instagram" style="font-size:30px; color: #e79797;" aria-hidden="true"></i></a>
		<a href="#" title="facebook"><i class="fa fa-facebook" style="font-size:30px; color: #e79797;" aria-hidden="true"></i></a>
		<a href="#" title="snapchat"><i class="fa fa-tumblr" style="font-size:30px; color: #e79797;" aria-hidden="true"></i></a>
	</div>
	</div>
	<div class="col-xs-4">
	<br/>
	<br/>
	<br/>
	<h2 style="font-family: Garamond; color: #e79797; text-align: center;">Newsletter</h2>
	</br>
		<form class="form-horizontal" action="newsletter.php" method="POST">
		<div class="form-group col-xs-8">
			<input type="email" class="form-control" name="emailnews" id="emailnews" placeholder="Insira seu e-mail"/>
		</div>
		<div class="col-xs-4">
			<input class="btn btn-carrinho" type="submit" value="Assinar">
		</div>
		</form>
	</div>
</footer>




	<!--  JQuery -->
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
	
	<!-- inserindo Java do Bootstrap -->
	<!-- Última versão Java compilada e minificada -->
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
	
	
</body>
</html>