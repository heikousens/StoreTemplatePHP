<?php
 include "includes/header.php"
?>
<!DOCTYPE html>
<html>
  <head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
   
    <link href="css/bootstrap.min.css" rel="stylesheet">
 
    <link href="css/Estilos.css" rel="stylesheet">

  
  </head>

  
  <body class="login-bg">

	
	<div class="page-content container">
		<div class="row">
			<div class="col-md-4 col-md-offset-4">
				<div class="login-wrapper">
			        <div class="box">
			            <div class="content-wrap">
							
							<br/>
							<br/>
			                <h2>ACESSO RESTRITO</h2>
			               <br/>
						   <br/>
				<form class="form-vertical" method="post" action="restrito-autenticar.php">
							
			                <input class="form-control" type="text" name="login" id="login"  placeholder="Usuário"><br/>
							<br/>
			                <input class="form-control" type="password" name="senha" id="senha" placeholder="Senha">
							<br/>
							<br/>
			                <div class="action">
			                    <button type="submit" class="btn btn-carrinho">Entrar</button>
								<a href="../index.php" class="btn btn-default" value="Home">Home</a>
			                </div>   
						</form>
								
			            </div>
			        </div>

			        
			    </div>
			</div>
		</div>
	</div>



    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="https://code.jquery.com/jquery.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="js/bootstrap.min.js"></script>
    <script src="js/custom.js"></script>
  </body>
</html>