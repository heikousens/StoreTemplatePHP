<?php
   if(!isset($_SESSION['cliente']));  
   if(!isset($_SESSION['clientenome']));  
   if(!isset($_SESSION['carrinho']));  
?>


<?php require "Include/header.php" ?>
<div class="container">
<?php require "Include/sidebar.php"; 
?>
<div class="col-md-9">
		  	<div class="row">
		<div class="col-md-12">
		<div class="thumbnail">
		<div class="content-box-large">
		 <div class="panel-heading">
		<div class="panel-title" align="center">
		<h2>Listagem de Produtos</h2>
		<br/>
		<?php echo $_SESSION['clientenome']; ?>, seus  pedidos:
	</div>
		</div>
		<div class="panel-body">
		
	<?php
	
	include('conexao.php');
	$codcliente = $_SESSION['cliente'];
	$sql = "SELECT * FROM pedido INNER JOIN produto ON pedido.codproduto = produto.codproduto where codcliente = '$codcliente'"; /* o codproduto da tabela pedido precisa ser igual ao codproduto da tabela produto */
	
	
	$executa = mysqli_query($conexao, $sql);
	if(mysqli_num_rows($executa) > 0 ){
		?>
     <table class="table table-strip">
		<thead>
			<tr>
				<th width="244">NOME</th>
				<th width="244">CATEGORIA</th>
				<th width="244">DATA COMPRA</th>
				<th width="244">QTD</th>
				<th width="244">PREÇO</th>
				<th width="244">SUBTOTAL</th>
				
				
			</tr>
			 <?php
        while($row = mysqli_fetch_array($executa)){
            ?>
            <tr>
				<td><?php echo $row["nomeproduto"];?></td>
				<td><?php echo $row["categoria"];?></td>
				<td><?php echo date('d/m/Y', strtotime($row["datacompra"])); ?></td>
							
				<td><?php echo $row["qtd"];?></td>
				<td><?php echo $row["sub"];?></td>
				<td><?php echo $row["total"];?></td>
			
            </tr>
            <?php
        } echo "</table>";
    }else{
        echo "Nenhum pedido encontrado!";
    }    mysqli_close($conexao); 
   
?>
			
			
			
		</thead>
		<tbody>
	
	
	
 </table>

	
 
 
		  				</div>
		  			</div>
  				</div>
  			</div> 

		  			</div>
		  		</div>		  		
		  	</div> 	
		  </div>
		</div>
    </div>

  <?php require "Include/footer.php" ?> 