<?php
   if(!isset($_SESSION['cliente']));  

   if(!isset($_SESSION['clientenome']));  
    if(!isset($_SESSION['clienteemail']));
	if(!isset($_SESSION['clientesenha']));
	if(!isset($_SESSION['carrinho']));
?>
<?php require "Include/header.php"; 
include('conexao.php');?>
<div class="container">
<?php require "Include/sidebar.php"; 
?>
<div class="col-md-9">
	<div class="row">
	<div class="col-md-12">
	<div class="thumbnail">
	<div class="content-box-large">
	<div class="panel-heading">
	<div class="panel-title" align="center">
	<h2>Listagem de Produtos</h2>
	<br/>
		<?php echo $_SESSION['clientenome']; ?>, confira seus pedidos:
	
	</div>
	</div>
	<div class="panel-body">
	<table class="table table-strip">
		<thead>
			<tr>
				<th width="244">NOME</th>
				<th width="244">QUANTIDADE</th>
				<th width="244">PREÇO</th>
				<th width="244">SUBTOTAL</th>
				<th width="244">REMOVER</th>
			</tr>
		</thead>
		<form action="?acao=finalizar" method="POST">
		<tbody>
		
		<?php
			if(count($_SESSION['carrinho']) == 0){
					
					echo('<tr><td colspan="5">Nenhum produto no carrinho</td></tr>');
					
				}else{
					
					include('conexao.php');
					$total = 0;
					foreach($_SESSION['carrinho'] as $codproduto=> $qtd){
						
						$sql     = "SELECT * FROM produto WHERE codproduto = '$codproduto'";
						$executa = mysqli_query($conexao, $sql) or die (mysqli_error());
						$in      = mysqli_fetch_assoc($executa);
						$nomeproduto  = $in['nomeproduto'];
						
					
						$preco   = number_format ($in['preco'], 2,',','.');
						$sub     = number_format ($in['preco'] * $qtd, 2,',','.');
						$total   += $in['preco'] * $qtd;
						/* As variáveis abaixo gravam a tabela "pedido" no banco de dados */
						$codcliente = $_SESSION['cliente'];
						$date = date('Y-m-d'); /* No MySQL, a data é armazenada como YYYY-MM-DD */
						$datacompra = $date; /* Variável auxiliar para receber a nova variável de data de compra. $Datacompra é uma variável que está armazenada no banco de dados */
						$sql22 = "INSERT INTO pedido VALUES (null,'".$codcliente."','".$codproduto."','".$qtd."','".$sub."','".$total."','".$datacompra."')";
						$gravar = mysqli_query($conexao,$sql22);
						$_SESSION['carrinho'] = array(); /* Depois que se finalizar a compra, essa variável zera o carrinho, para não repetir o pedido, ou seja, essa variável encerra a sessão do carrinho */
						
						echo '<tr>
				
								
                               <td>'.$nomeproduto.'</td> 
								<td><input type="text" size="3" name="prod['.$codproduto.']" value="'.$qtd.'" ></td>
                                
								<td>R$ '.$preco.'</td>
                                
								<td>R$'.$sub.'</td>
                                
								<td><a href="?acao=del&codproduto='.$codproduto.'" class="btn btn-finalizar" style="color: #FFFFFF;">Remover</td>

							  </tr>' ;
					}
					
						$total = number_format($total, 2, ',', '.');
                echo 	'<tr>                         
                            <td colspan="4">Total</td>
                            <td>R$ '.$total.'</td>
                    	</tr>';
				}
		?>
		
		
	</div> 

		</tr>
	
				
		
 </table>
	</div>
	</div>
  	</div>
  	</div> 
    </div>
	</div>
</div>
  <?php require "Include/footer.php" ?>