<?php
$servidor = 'localhost';
$usuario  = 'root';
$senha 	  = '';
$banco 	  = 'projetophp';
$conexao  = mysqli_connect($servidor, $usuario, $senha, $banco);

?>