<?php
   if(!isset($_SESSION['cliente']));  
   if(!isset($_SESSION['clientenome']));  
    if(!isset($_SESSION['clienteemail']));
	if(!isset($_SESSION['clientesenha']));
?>
<?php require "Include/header.php"; 
include('conexao.php');?>
<div class="container">
<?php require "Include/sidebar.php"; 
?>
<div class="col-md-9">
	<div class="row">
	<div class="col-md-12">
	<div class="thumbnail">
	<div class="content-box-large">
	<div class="panel-heading">
	<div class="panel-title">
	<h1>Dados do Cliente</h1>
		Seu código de Cliente é  <?php echo $_SESSION['cliente']; ?>
	
	</div>
	</div>
	<div class="panel-body">
	<table class="table table-strip">
		<thead>
			<tr>
				<th width="244">NOME</th>
				<th width="244">E-MAIL</th>
				<th width="244">SENHA</th>
			</tr>
		</thead>
		<tbody>
		
		<?php echo '<td>';?>  <?php echo $_SESSION['clientenome']; ?>
		<?php echo '</td>';?>
		<?php echo '<td>';?>  <?php echo $_SESSION['clienteemail']; ?> 
		<?php echo '</td>';?>
		<?php echo '<td>';?> <?php echo $_SESSION['clientesenha']; ?>
		<?php echo '</td>';?>
		
		
	</div> 
		
        <td><a href="?acao=del&cliente" class="btn btn-finalizar" style="color: #FFFFFF;">Remover</td>
		<td><a href="?acao=alterar&cliente" class="btn btn-default">Alterar</td>
		</tr>
	
				
		
 </table>
	</div>
	</div>
  	</div>
  	</div> 
    </div>
	</div>
</div>	
	</section>			
 </section>
  <?php require "Include/footer.php" ?>