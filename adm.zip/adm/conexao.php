<?php
$servidor = 'localhost';
$usuario  = 'root';
$senha 	  = '';
$banco 	  = 'aulaphp';
$conexao  = mysqli_connect($servidor, $usuario, $senha, $banco);

?>