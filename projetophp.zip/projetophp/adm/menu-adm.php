	<nav class="navbar navbar-expand-lg bg-dark">
		<div class="container">
			<a class="navbar-brand" href="index.php"><img src="img/logo-pena.png" alt="" class="w-50 h-50"></a>
			<ul class="navbar-nav mr-auto mt-2 mt-lg-0">
				<li class="nav-item">
					<a class="nav-link" href="produtoimagem.php">CADASTRAR Produto</a>
				</li>
				<li class="nav-item">
					<a class="nav-link" href="cadcliente.php">CADASTRAR NOVO Cliente</a>
				</li>
			</ul>
		</div>
	</nav>