﻿<html>
<head>
<title>Alterar Produto</title>
<meta charset="UTF-8">
 <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
 <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
 <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>

</head>
<body>
<div class="container">
<fieldset>
<legend>Alterar Produto</legend>
<form method="POST" action="alteraproduto2.php">

Cod do Produto:
<input type="text"  name="codproduto" />
<input type="submit" class="btn-success" value="Alterar Produto"/>
</form>
</fieldset>
<a href="menu.php">Voltar tela inicial</a>
</div>
</body>
</html>
