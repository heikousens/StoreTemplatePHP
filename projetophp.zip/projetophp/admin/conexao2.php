<?php
$servidor = 'localhost';
$usuario  = 'root';
$senha 	  = '';
$banco 	  = 'projetophp';
	try{
	  $conexao = new PDO('mysql:host='.$servidor.';dbname=projetophp', $usuario, $senha);  
	  $conn = new PDO('mysql:host='.$servidor.';dbname=projetophp', $usuario, $senha);  
	}
	catch(PDOException $e){
		echo $e->getMessage();
	}
?>