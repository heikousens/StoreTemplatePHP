<?php 

$codcliente = $_GET['codcliente'];

require "Cliente.class.php";

$cliente = new Cliente();
$cliente->codcliente = $codcliente;
$cliente->excluir();
$msg = "Excluido com sucesso!";

?>

<?php $title = "Excluir Cliente"; ?>
<?php include "includes/header.php"; ?>

<section class="container">
	<?php require "includes/sidebar.php" ?> 
	<div class="col-md-9">
		  	<div class="row">
		<div class="col-md-12">
		<div class="thumbnail">
    <?php echo $msg; ?>
	</div>
	</div>
</section>

<?php include "includes/footer.php"; ?>