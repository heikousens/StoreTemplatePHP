<?php
require "Produtos.class.php";

$nomeproduto = $_POST['nomeproduto'];
$produto= new Produto();
$dados = $produto->pesquisarPorNome($nomeproduto);

?>

<?php $title = "Listagem de Produtos"; ?>
<?php include "includes/header.php" ?>

    <section class="container">
	<?php require "includes/sidebar.php" ?> 
	<div class="col-md-9">
	<div class="thumbnail">
        <h1 align="center">Pesquisa por: <?php echo $nomeproduto; ?></h1>
        
        <?php if(isset($dados)){ ?>

		  	<div class="row">
  				<div class="col-md-12">
  					
		
		  				<div class="panel-body">
		  					<table class="table">
				              <thead>
				                <tr>
				                  <th>CÓDIGO</th>
								  <th>NOME</th>
				                  <th>DESCRIÇÃO</th>
				                  <th>CATEGORIA</th>
				                  <th>PREÇO</th>
				           
				                  <th>IMAGENS</th>
				                </tr>
				              </thead>
				               <?php
    
								
								 foreach($dados as $dado => $coluna){
												echo "<tr>";
												echo "<td>".$coluna['codproduto']."</td>";
												echo "<td>".$coluna['nomeproduto']."</td>";
												echo "<td>".$coluna['descricao']."</td>";
												echo "<td>".$coluna['categoria']."</td>";
												echo "<td>".$coluna['preco']."</td>";
											 
												echo "<td><img src='../Imagens/".$coluna['imagem']."' height='100'/>";"</td>";
												echo "</tr>";
											
											}
											
											
								?>
								
								
								   <?php } ?>
				            </table>
		  				</div>
		  			</div>
  				</div>
  			</div>
		</div>
    </section>

<?php include "includes/footer.php" ?>