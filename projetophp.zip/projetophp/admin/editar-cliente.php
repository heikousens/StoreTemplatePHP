<?php
	include_once("conexao.php");
	$codcliente= $_GET['codcliente'];
	//Buscar os dados referente ao usuario situado neste id
	$result_cliente = "SELECT * FROM cliente INNER JOIN emailcli ON codcliente= codemail WHERE codcliente = '$codcliente' LIMIT 1";
	$resultado_cliente = mysqli_query($conn, $result_cliente);
	$row_cliente = mysqli_fetch_assoc($resultado_cliente);	
?>
<?php include "includes/header.php" ?>
<section class="container">
	<?php require "includes/sidebar.php" ?> 
	<div class="col-md-9">
		  	<div class="row">
		<div class="col-md-12">
		<div class="thumbnail">
		  			<div class="content-box-large">
		  				<div class="panel-heading">
							<div class="panel-title">
				  <h1 align="center">Editar Cliente</h1>
			</div>
						</div>
		  	<div class="panel-body">
			<form class="form-horizontal" method="POST" action="processar_editar_cliente.php" enctype="multipart/form-data">
			
				<div class="form-group">
					<label class="col-sm-2 control-label">Nome</label>
					<div class="col-sm-10">
						<input type="text" name="nome" class="form-control" id="inputEmail3" placeholder="Nome Completo" value="<?php echo $row_cliente['nome']; ?>">
					</div>
				</div>
				
		
				
				<div class="form-group">
					<label class="col-sm-2 control-label">E-mail</label>
					<div class="col-sm-10">
						<input type="text" name="email" class="form-control" id="inputEmail3" placeholder="E-mail" value="<?php echo $row_cliente['email']; ?>">
					</div>
				</div>
				
			
				
				<div class="form-group">
					<label class="col-sm-2 control-label">Senha</label>
					<div class="col-sm-10">
						<input type="text" name="senha" class="form-control" id="inputEmail3" placeholder="E-mail" value="<?php echo $row_cliente['senha']; ?>">
					</div>
				</div>
				
					
				<input type="hidden" name="codcliente" value="<?php echo $row_cliente['codcliente']; ?>">
				<div class="form-group">
					<div class="col-sm-offset-2 col-sm-10">
						<button type="submit" class="btn btn-carrinho">Alterar</button>
					</div>
				</div>
			</form>
					</div>
		  		</div>		  		
		  	</div> 	
		  </div>
		</div>
    </div>
<?php include "includes/footer.php" ?>