<?php $title ="Pesquisa de produtos"; ?>
<?php include "includes/header.php" ?>
  
<div class="container">
  <?php require "includes/sidebar.php" ?>    
	<div class="col-md-9">
		  	<div class="row">
		<div class="col-md-12">
		<div class="thumbnail">
		  			<div class="content-box-large">
		  				<div class="panel-heading">
							<div class="panel-title" align="center">
				  <h1>Pesquisar Produtos</h1>
			</div>
						</div>
		  	<div class="panel-body">
				<form class="form-system" method="post" 
					  action="produto-pesquisa-nome.php">

					<div class="form-group">
							<label class="col-sm-2 control-label">Nome do Produto:</label>
							<div class="col-sm-5">
								<input type="text"  name="nomeproduto" class="form-control"/>
							</div>
							
							
					</div>		
					
					
			<label></label>
			<input type="submit"  class="btn btn-carrinho" name="botao" value="Pesquisar" /> 
		</form>
        </div>
		</div>
		</div>
		</div></div></div>
		</div>
    
    <?php include "includes/footer.php"; ?>
    
