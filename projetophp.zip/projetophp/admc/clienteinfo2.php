<?php session_start(); ?>
<?php
   if(!isset($_SESSION['cliente']));  

   if(!isset($_SESSION['clientenome']));  
?>
<?php require "admin.php"; 
include('conexao.php');?>
<div class="col-md-10">
	<div class="row">
	<div class="col-md-12">
	<div class="content-box-large">
	<div class="panel-heading">
	<div class="panel-title">
	<h1>Dados do Cliente</h1>
		Seu código de Cliente é  <?php echo $_SESSION['cliente']; ?>
	</div>

	<div class="panel-options">
		<a href="#" data-rel="collapse"><i class="glyphicon glyphicon-refresh"></i></a>
		<a href="#" data-rel="reload"><i class="glyphicon glyphicon-cog"></i></a>
	</div>
	</div>
	<div class="panel-body">
	<table class="table table-strip">
		<thead>
			<tr>
				<th width="244">NOME</th>
				<th width="244">E-MAIL</th>
				<th width="244">SENHA</th>
			</tr>
		</thead>
		<tbody>
		<?php
		if(count($_SESSION['cliente'])== 0){
		echo('<tr><td colspan="5">Nenhum cliente encontrado</td></tr>');
		}else{
	    $sql = "SELECT * FROM cliente";
		$executa = mysqli_query($conexao, $sql) or die (mysqli_error());
		$in      = mysqli_fetch_assoc($executa);
		$nome    = $in ['nome'];
		$email   = $in ['email'];
		$senha    = $in ['senha'];
        echo '<tr>
		<td>'.$nome.'</td>
        <td> '.$email.'</td>
        <td>'.$senha.'</td>
        <td><a href="?acao=del&cliente" class="btn btn-danger">Remover</td>
		<td><a href="?acao=alterar&cliente" class="btn btn-success">Alterar</td>
		</tr>' ;
		}
				
		?>
 </table>
	</div>
	</div>
  	</div>
  	</div> 
    </div>
	</div>		  		
	</div> 	
	</div>
	</div>
    </div>
	</section>			
 </section>
  <?php require "footer.php" ?> 