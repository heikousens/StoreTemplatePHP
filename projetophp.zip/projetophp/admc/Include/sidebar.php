<div class="col-xs-12 col-sm-12 col-md-3 col-lg-3">
	<div class="panel-group">
		<div class="panel panel-default">
			<div class="panel-heading" style="font: 19px Garamond; background-color: #EEB4B4;"><a href="index.php" style="color: #FFFFFF;"><i class="glyphicon glyphicon-home"></i> Início</a></div>
		</div>
		<br/>
		<div class="panel panel-default">
			<a data-toggle="collapse" href="#collapse1"><div class="panel-heading" style="font: 19px Garamond; background-color: #EEB4B4; color: #FFFFFF;"><i class="glyphicon glyphicon-lock"></i> Área do Cliente</div></a>
			<div id="collapse1" class="panel-collapse collapse">
					  <div class="panel-body" style="font: 19px Garamond;"><a href="clienteinfo.php"><i class="icon-inbox"></i>Meus Dados</a></div>
					  <div class="panel-body" style="font: 19px Garamond;"><a href="pesquisarpedidos.php"><i class="icon-inbox"></i>Finalizar Compra </a></div>
					  <div class="panel-body" style="font: 19px Garamond;"><a href="pedidos.php"><i class="icon-inbox"></i>Meus Pedidos </a></div>
					  </div>
					</div>
					<br/>
					<div class="panel panel-default">
					<div class="panel-heading" style="font: 19px Garamond; background-color: #EEB4B4;"><a href="logoff.php" style="color: #FFFFFF;"><i class="glyphicon glyphicon-log-out"></i> Sair</a></div>
					</div>
	</div>
</div>