<?php
include "Include/header.php"
?>
<?php
   if(!isset($_SESSION['cliente']));  
   if(!isset($_SESSION['clientenome']));  
    if(!isset($_SESSION['clientesenha']));
   if(!isset($_SESSION['carrinho']));  
   
?>
<div class="container">
<div class="row">
<div class="col-xs-12">
<?php include "Include/sidebar.php" ?>
		  <div class="col-md-9">
		  	<div class="row">
		  		<div class="col-md-12">
				<div class="thumbnail">
		  			<div class="content-box-large">
		  				<div class="panel-heading">
							<div class="welcome-title">Bem Vindo à Área do Cliente, <?php echo $_SESSION['clientenome']; ?></div>
						</div>
						<br/>
						<br/>
		  				<div class="body-text">
						<p>Esta área permite controlar todas as informações que são armazenadas no banco de dados</p>
						<p>O Administrador poderá alterar e fazer modificações em seu dados e verificar o que foi repassado pelos seus clientes.</p>
									  			
		  				</div>
		  			</div>
		  		</div>		  		
		  	</div> 	
		  </div>
		</div>
	</div>
</div>
</div>
<?php include "Include/footer.php" ?>