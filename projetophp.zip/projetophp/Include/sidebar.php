	<div class="col-xs-12 col-sm-12 col-md-offset-1 col-md-2 col-lg-offset-1 col-lg-2">
		<div style="margin-top:0px;">
			<div class="caption">
				<p style="line-height: 25px;">Inspirada em Tarsila do Amaral, a <b>tarsila.</b> é uma loja virtual que traz o que existe de melhor em suprimentos para artistas.</p>
			</div>
		</div>
		<div class="page-header" style="margin-top:0px;">
			<div class="caption" align="left">
				<br/>
					<a href="contato.php" id="sidebar"><i class="fa fa-envelope" style="color:#EEB4B4;" aria-hidden="true"></i> Contato</a>
			</div>
		</div>
		<div class="page-header" style="margin-top:0px;">
			<div class="caption" align="left">
				<br/>
					<a href="#" id="sidebar"><i class="fa fa-flag" style="color:#EEB4B4;" aria-hidden="true"></i> Políticas da Loja</a>
			</div>
		</div>
		<div class="page-header" style="margin-top:0px;">
			<div class="caption" align="left">
				<br/>
					<a href="#" id="sidebar"><i class="fa fa-coffee" style="color:#EEB4B4;" aria-hidden="true"></i> FAQ</a>
			</div>
		</div>
		<div class="page-header" style="margin-top:0px;">
			<div class="caption" align="left">
				<br/>
					<a href="#" id="sidebar"><i class="fa fa-suitcase" style="color:#EEB4B4;" aria-hidden="true"></i> Política de Privacidade</a>
			</div>
		</div>
		<br/>
		<div style="margin-top:0px;">
			<div class="caption" align="center">
				<h4 style="text-align:center;">Redes Sociais</h4>
				<br/>
					<a href="#" title="twitter"><i class="fa fa-twitter" style="font-size:20px; color: #EEB4B4;" aria-hidden="true"></i></a>
					<a href="#" title="instagram"><i class="fa fa-instagram" style="font-size:20px; color: #EEB4B4;" aria-hidden="true"></i></a>
					<a href="#" title="facebook"><i class="fa fa-facebook" style="font-size:20px; color: #EEB4B4;" aria-hidden="true"></i></a>
					<a href="#" title="snapchat"><i class="fa fa-snapchat-ghost" style="font-size:20px; color: #EEB4B4;" aria-hidden="true"></i></a>
			</div>
		</div>
	</div>