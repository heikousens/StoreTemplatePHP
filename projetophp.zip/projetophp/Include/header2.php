<!doctype html>
<html>
<head>
    <title>Tarsila.</title>
    <meta charset="utf-8"/>
	<link rel="shortcut icon" type="image/png" href="Imagens/a23baf44a21838b31e2c115d4679b796.png"/>
    
    <!-- define a viewport -->
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    
    <!-- inserindo css do Bootstrap -->
	<link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" rel="stylesheet" media="all" /><!-- modo online -->
	
	<!-- inserindo css do Font Awesome -->
	<link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" media="all" /><!-- Banco de ícones para o site -->
    
    <!-- inserindo css personalizado -->
    <link href="CSS/Estilos.css" rel="stylesheet" media="all" />
	
	<!-- JQuery da galeria -->
	<script type="text/javascript" src="js/jquery.js" ></script>
	
		<!--  JQuery -->
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
	
	<!-- inserindo Java do Bootstrap -->
	<!-- Última versão Java compilada e minificada -->
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
	
</head>
    
<body>

<!-- Início da nav -->

<nav class="navbar navbar-default navbar-fixed-top" id="navbar">
  <div class="container-fluid">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span> 
      </button>
      <a class="navbar-brand" href="index.php">tarsila.</a>
    </div>
    <div class="collapse navbar-collapse" id="myNavbar">
      <ul class="nav navbar-nav">
        <li><a href="index.php">Home</a></li>
        <li class="dropdown" id="dropdown">
			<a href="Desenho.php" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="true">Desenho<span class="caret"></span></a>
				<ul class="dropdown-menu">
					<li><a href="lapis.php">Lápis & Lapiseira</a></li>
					<li><a href="canetas.php">Canetas</a></li>
					<li><a href="marcadores.php">Marcadores</a></li>
					<li><a href="tinta.php">Tinta</a></li>
					<li><a href="pincel.php">Pincel</a></li>
					<li><a href="acessorios.php">Acessórios</a></li>
				</ul>
		</li>
        <li class="dropdown" id="dropdown">
			<a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="true">Papel<span class="caret"></span></a>
				<ul class="dropdown-menu">
					<li><a href="bloco.php">Bloco de Desenho</a></li>
					<li><a href="cadernos.php">Cadernos</a></li>
					<li><a href="agenda.php">Agenda & Planner</a></li>
					<li><a href="notas.php">Notas autoadesivas</a></li>
				</ul>
		</li>
        <li><a href="diversos.php">Diversos</a></li> 
      </ul>
      <ul class="nav navbar-nav navbar-right">
	  <?php
        if(!isset($_SESSION['clientenome'])){
        ?>
        <li><a href="login.php"><span class="glyphicon glyphicon-log-in"></span> Entrar</a></li>
		<?php
        } else{
echo "
		<li>
            <div style='font-family: sans-serif; font-size: 10px; line-height: 50px; text-transform:uppercase; letter-spacing:1px;'>Olá, " . $_SESSION['clientenome']  ."</div>
        </li>
        <li>
            <a href=logoff.php>Sair</a>
        </li>";

        }
		?>
		<li><a href="admin/login.php"><span class="fa fa-lock"></span> Acesso Restrito</a></li>
		<li><a href="carrinho.php"><i class="fa fa-shopping-basket"></i> Carrinho</a></li>
      </ul>
    </div>
  </div>
</nav>


<!-- Fim da nav -->
<br/>
<br/>
<header id="topbar">
	<div class="col-xs-12 col-sm-12 col-lg-offset-1 col-lg-10 col-md-offset-1 col-md-10">
		<h1><a href="index.php">tarsila.</a></h1><h2>stationery & art supplies</h2>
	</div>
</header>
<br/>
<br/>